// Navigation.js

import React from 'react';
import { Link } from 'react-router-dom';
import './Navigation.css';

const Navigation = () => {
    return (
        <ul className="nav-menu">
           <li> <Link to="/login">Login</Link></li>
            <li><Link to="/signup">Signup</Link></li>
            <li><Link to="/bookmanager">Book Manager</Link></li>
        </ul>
    );
}

export default Navigation;
