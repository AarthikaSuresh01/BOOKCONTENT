

import React from 'react';
import './HomePage.css';

const HomePage = () => (
    <div className='home'>
        <h1>Welcome to Our Website</h1>
        <p>Explore our features:</p>
        <ul>
           <li><a href="/login">Login</a></li>
            <li><a href="/signup">Signup</a></li>
            <li><a href="/bookmanager">Book Manager</a></li>
            <li><a href="/contact-us">Contact Us</a></li>
        </ul>
    </div>
);

export default HomePage;
