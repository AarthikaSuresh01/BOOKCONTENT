import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'; // Import BrowserRouter and Routes
import Login from './Components/Login';
import Signup from './Components/Signup';
import BookManager from './Components/BookManager'; 
// Import BookManager component
//import Navigation from './Components/Navigation';
import HomePage from './Components/HomePage';


function App() {
  return (
    <Router>
    <div className='app'>
    
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/bookmanager" element={<BookManager />} />
        
      </Routes>
      </div>
    </Router>
  );
}

export default App;
